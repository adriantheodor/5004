package tiles;

import java.util.NoSuchElementException;

/**
 * This class represents a rectangle.
 * 
 *
 */
public class Rectangle {
  private double x;
  private double y;
  private double width;
  private double height;

  /**
   * Constructs a Rectangle object with the given location of its lower-left
   * corner and dimensions.
   * 
   * @param x     x-coordinate of the lower left corner of this rectangle
   * @param y     y-coordinate of the lower left corner of this rectangle
   * @param width  width of this rectangle
   * @param height height of this rectangle
   * @throws IllegalArgumentException if height or width is negative.
   */
  public Rectangle(double x, double y, double width, double height)
      throws IllegalArgumentException {
    if (width < 0) {
      throw new IllegalArgumentException("Width must be greater than zero.");
    }

    if (height < 0) {
      throw new IllegalArgumentException("Height must be greater than zero.");
    }

    this.x = x;
    this.y = y;
    this.width = width;
    this.height = height;
  }

  /**
   * Return the Euclidean x value of the bottom left corner of this rectangle.
   * 
   * @return x the Euclidian X value of the bottom left corner of this Rectangle.
   */
  public double getX() {
    return this.x;
  }

  /**
   * Return the Euclidean y value of the bottom left corner of this rectangle.
   * 
   * @return y the Euclidian y value of the bottom left corner of this Rectangle.
   */
  public double getY() {
    return this.y;
  }

  /**
   * Return the width of this Rectangle.
   * 
   * @return width the with of this rectangle.
   */
  public double getWidth() {
    return this.width;
  }

  /**
   * Return the height of this rectangle.
   * 
   * @return height the height of this rectangle.
   */
  public double getHeight() {
    return this.height;
  }

  /**
   * Return a boolean value based on whether two rectangle objects overlap one
   * another.
   * 
   * @param other - a different Rectangle object
   * @return the boolean value depending on if the other rectangle overlaps with
   *         this rectangle.
   */
  public boolean overlap(Rectangle other) {
    double upperRightCornerX = this.x + this.width;
    double upperRightCornerY = this.y + this.height;
    double otherUpperRightCornerX = other.x + other.width;
    double otherUpperRightCornerY = other.y + other.height;

    if (this.getX() == upperRightCornerX || this.getY() == upperRightCornerY
        || other.getX() == otherUpperRightCornerX || other.getY() == otherUpperRightCornerY) {
      return false;
    }

    if (upperRightCornerY <= other.getY() || this.getY() >= otherUpperRightCornerY) {
      return false;
    }

    if (upperRightCornerX < other.getX() || this.getX() >= otherUpperRightCornerX) {
      return false;
    }

    return true;
  }

  /**
   * Return newRectangle a new Rectangle object that represents the intersection
   * of two rectangles.
   * 
   * @param other - an other Rectangle object
   * @return newRectangle - a new Rectangle that represents the intersection of
   *         this Rectangle and the other.
   * @throws NoSuchElementException when there is no intersection to represent.
   */
  public Rectangle intersect(Rectangle other) throws NoSuchElementException {
    double upperRightCornerX = this.x + this.width;
    double upperRightCornerY = this.y + this.height;
    double otherUpperRightCornerX = other.x + other.width;
    double otherUpperRightCornerY = other.y + other.height;
    Rectangle newRectangle;

    // Bottom Left of intersection
    double intersectionBottomLeftX = Math.max(this.getX(), other.getX());
    double intersectionBottomLeftY = Math.max(this.getY(), other.getY());

    // Top Right of intersection
    double intersectionTopRightX = Math.min(upperRightCornerX, otherUpperRightCornerX);
    double intersectionTopRightY = Math.min(upperRightCornerY, otherUpperRightCornerY);

    if (intersectionBottomLeftX >= intersectionTopRightX
        || intersectionBottomLeftY >= intersectionTopRightY) {
      throw new NoSuchElementException("There is no intersection!");
    }

    double newWidth = intersectionTopRightX - intersectionBottomLeftX;
    double newHeight = intersectionTopRightY - intersectionBottomLeftY;
    newRectangle = new Rectangle(intersectionBottomLeftX, intersectionBottomLeftY, newWidth,
        newHeight);
    return newRectangle;
  }

  /**
   * Return a new Rectangle object that represents the union of this rectangle and
   * the other.
   * 
   * @param other - a different Rectangle object
   * @return newRectangle - a new Rectangle object that represents a union of this
   *         Rectangle and other.
   */
  public Rectangle union(Rectangle other) {
    double upperRightCornerX = this.x + this.width;
    double upperRightCornerY = this.y + this.height;
    double otherUpperRightCornerX = other.x + other.width;
    double otherUpperRightCornerY = other.y + other.height;
    Rectangle newRectangle;

    double minimumX = Math.min(this.getX(), other.getX());
    double minimumY = Math.min(this.getY(), other.getY());
    double maximumX = Math.max(upperRightCornerX, otherUpperRightCornerX);
    double maximumY = Math.max(upperRightCornerY, otherUpperRightCornerY);

    double newWidth = maximumX - minimumX;
    double newHeight = maximumY - minimumY;

    newRectangle = new Rectangle(minimumX, minimumY, newWidth, newHeight);

    return newRectangle;
  }

  /**
   * Return a formatted string representation of this rectangle
   * 
   * "x:%.3f, y:%.3f, w:%.3f, h:%.3f"
   * 
   * @return a formatted String representation of this rectangle.
   */
  @Override
  public String toString() {
    return String.format("x:%.3f, y:%.3f, w:%.3f, h:%.3f", this.x, this.y, this.width, this.height);
  }
}
