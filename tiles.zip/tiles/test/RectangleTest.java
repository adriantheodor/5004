import static org.junit.Assert.assertEquals;

import java.util.NoSuchElementException;

import org.junit.Before;
import org.junit.Test;

import tiles.Rectangle;

public class RectangleTest {

  private Rectangle rectangleTwo;
  private Rectangle rectangleFour;

  @Before
  public void setUp() {
    rectangleTwo = new Rectangle(-3.45, 8.228, 10, 23);
  }

  @Test
  public void testConstructor() {
    rectangleFour = new Rectangle(3, 3, 16, 9);
    assertEquals(3, rectangleFour.getX(), 0.001);
    assertEquals(3, rectangleFour.getY(), 0.001);
    assertEquals(16, rectangleFour.getWidth(), 0.001);
    assertEquals(9, rectangleFour.getHeight(), 0.001);

  }

  @Test(expected = IllegalArgumentException.class)
  public void testIllegalHeight() {
    Rectangle rectangleThree;

    rectangleThree = new Rectangle(0, 0, -2, 3.432);
  }

  @Test(expected = IllegalArgumentException.class)
  public void testIllegalWidth() {
    Rectangle rectangleOne;

    rectangleOne = new Rectangle(0, 0, 3.234, -2);
  }

  @Test
  public void testGetX() {
    assertEquals(-3.45, rectangleTwo.getX(), 0.001);
  }

  @Test
  public void testGetY() {
    assertEquals(8.228, rectangleTwo.getY(), 0.001);
  }

  @Test
  public void testGetWidth() {
    assertEquals(10, rectangleTwo.getWidth(), 0.001);
  }

  @Test
  public void testGetHeight() {
    assertEquals(23, rectangleTwo.getHeight(), 0.001);
  }

  @Test
  public void testOverlapOne() {
    Rectangle rectangleFive;
    Rectangle rectangleSix;

    rectangleFive = new Rectangle(0, 0, 10, 10);
    rectangleSix = new Rectangle(1, 1, 1, 1);
    assertEquals(true, rectangleFive.overlap(rectangleSix));
  }

  @Test
  public void testOverlapTwo() {
    Rectangle rectangleFive;
    Rectangle rectangleSix;

    rectangleFive = new Rectangle(0, 0, 10, 10);
    rectangleSix = new Rectangle(-1, -1, 1, 1);
    assertEquals(false, rectangleFive.overlap(rectangleSix));
  }

  @Test
  public void testOverlapThree() {
    Rectangle rectangleFive;
    Rectangle rectangleSix;

    rectangleFive = new Rectangle(0, 0, 10, 10);
    rectangleSix = new Rectangle(-12, -12, 1, 1);
    assertEquals(false, rectangleFive.overlap(rectangleSix));
  }

  @Test
  public void testIntersection() {
    Rectangle rectangleFive;
    Rectangle rectangleSix;
    Rectangle rectangleSeven;
    rectangleFive = new Rectangle(0, 0, 10, 10);
    rectangleSix = new Rectangle(1, 1, 1, 1);
    rectangleSeven = rectangleFive.intersect(rectangleSix);
    assertEquals(1, rectangleSeven.getWidth(), 0.001);
    assertEquals(1, rectangleSeven.getX(), 0.001);
  }

  @Test
  public void testIntersectionTwo() {
    Rectangle rectangleFive;
    Rectangle rectangleSix;
    Rectangle rectangleSeven;
    rectangleFive = new Rectangle(0, 0, 10, 10);
    rectangleSix = new Rectangle(1, 1, 1, 1);
    rectangleSeven = rectangleFive.intersect(rectangleSix);
    assertEquals(1, rectangleSeven.getX(), 0.001);
  }

  @Test(expected = NoSuchElementException.class)
  public void testIllegalIntersection() {
    Rectangle rectangleFive;
    Rectangle rectangleSix;
    Rectangle rectangleSeven;

    rectangleFive = new Rectangle(0, 0, 10, 10);
    rectangleSix = new Rectangle(-1, -1, 1, 1);
    rectangleSeven = rectangleFive.intersect(rectangleSix);
  }

  @Test
  public void testUnion() {
    Rectangle rectangleFive;
    Rectangle rectangleSix;
    Rectangle rectangleSeven;
    rectangleFive = new Rectangle(0, 0, 10, 10);
    rectangleSix = new Rectangle(-1, -1, 1, 1);
    rectangleSeven = rectangleFive.union(rectangleSix);
    assertEquals(11, rectangleSeven.getWidth(), 0.001);
  }

  @Test
  public void testUnionTwo() {
    Rectangle rectangleFive;
    Rectangle rectangleSix;
    Rectangle rectangleSeven;
    rectangleFive = new Rectangle(0, 0, 10, 10);
    rectangleSix = new Rectangle(1, 1, 1, 1);
    rectangleSeven = rectangleFive.union(rectangleSix);
    assertEquals(0, rectangleSeven.getX(), 0.001);
  }

  @Test
  public void testtoString() {
    assertEquals("x:-3.450, y:8.228, w:10.000, h:23.000", rectangleTwo.toString());
  }

}
